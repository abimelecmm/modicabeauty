﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'sr-latn', {
	anchor: 'Unesi/izmeni sidro',
	flash: 'Flash Animation', // MISSING
	hiddenfield: 'Skriveno polje',
	iframe: 'IFrame', // MISSING
	unknown: 'Unknown Object' // MISSING
} );
