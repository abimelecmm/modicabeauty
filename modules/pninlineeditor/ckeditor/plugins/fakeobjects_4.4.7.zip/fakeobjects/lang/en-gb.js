﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'en-gb', {
	anchor: 'Anchor',
	flash: 'Flash Animation',
	hiddenfield: 'Hidden Field',
	iframe: 'IFrame',
	unknown: 'Unknown Object'
} );
