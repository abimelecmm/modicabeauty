<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_blockfacebooklike}prestashop>pk_blockfacebooklike_98b82c200a2e309b24cb481970f3fcc4'] = 'Come';
$_MODULE['<{pk_blockfacebooklike}prestashop>pk_blockfacebooklike_bfe6ec9dd9f9fbd54630637d521c89e6'] = 'persone come';
