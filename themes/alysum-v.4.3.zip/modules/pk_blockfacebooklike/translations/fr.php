<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_blockfacebooklike}venedor>pk_blockfacebooklike_98b82c200a2e309b24cb481970f3fcc4'] = 'J\'aime';
$_MODULE['<{pk_blockfacebooklike}venedor>pk_blockfacebooklike_c9fee138bfe3fbd940f268b63a5bcca1'] = 'personnes aiment';
