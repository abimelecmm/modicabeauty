<?php
require_once _PS_MODULE_DIR_ . 'ph_simpleblog/ph_simpleblog.php';

class SimpleBlogHelper
{
	public static function uploadImage($type = 'cover', $path = null, Array $params)
	{
		
	}
}