<?php
require_once _PS_MODULE_DIR_ . 'ph_simpleblog/ph_simpleblog.php';
require_once _PS_MODULE_DIR_ . 'ph_simpleblog/controllers/front/list.php';

class ph_simpleblogpageModuleFrontController extends ph_simplebloglistModuleFrontController {}