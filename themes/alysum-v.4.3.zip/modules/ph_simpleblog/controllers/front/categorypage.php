<?php
require_once _PS_MODULE_DIR_ . 'ph_simpleblog/ph_simpleblog.php';
require_once _PS_MODULE_DIR_ . 'ph_simpleblog/controllers/front/list.php';

class PH_SimpleBlogCategoryPageModuleFrontController extends ph_simplebloglistModuleFrontController {}