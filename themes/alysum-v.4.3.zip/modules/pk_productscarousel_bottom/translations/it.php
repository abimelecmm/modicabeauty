<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_productscarousel_bottom}alysum>pk_productscarousel_bottom_2d0f6b8300be19cf35e89e66f0677f95'] = 'Acquistare';
$_MODULE['<{pk_productscarousel_bottom}alysum>pk_productscarousel_bottom_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizzare';
