<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ph_recentposts}prestashop>ph_recentposts_7c0f88f909de8b873c75bd018bda9408'] = 'Musisz posiadać zainstalowany moduł ph_simpleblog przed użyciem tego modułu';
$_MODULE['<{ph_recentposts}prestashop>ph_recentposts_d3193f367fc7aeb00853d190eaf96e02'] = 'SimpleBlog - Ostatnie wpisy';
$_MODULE['<{ph_recentposts}prestashop>ph_recentposts_3e2ac4a737903364fea3d15cfb187743'] = 'Widget do wyświetlania ostatnich wpisów z modułu SimpleBlog';
$_MODULE['<{ph_recentposts}prestashop>ph_recentposts_d6f47e627cb8b9186caa435aba1c32ae'] = 'Na pewno usunąć?';
$_MODULE['<{ph_recentposts}prestashop>recent_39fd7f2ac3aad9fd0896bfeeb02fb267'] = 'Ostatnie wpisy';
$_MODULE['<{ph_recentposts}prestashop>recent_0746618781a2a85b5edf43bd3817064b'] = 'Link do';
$_MODULE['<{ph_recentposts}prestashop>recent_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Czytaj dalej';
$_MODULE['<{ph_recentposts}prestashop>recent_88a11208346ae5b4ca218d90fa29eb8b'] = 'Dodano:';
$_MODULE['<{ph_recentposts}prestashop>recent_91401f053501b716b4a695b048c9b827'] = 'Autor:';
$_MODULE['<{ph_recentposts}prestashop>recent_32b502f33a535f75dcbf63f6753c631e'] = 'Tagi:';
$_MODULE['<{ph_recentposts}prestashop>recent_061fcdd72d275db7234f4d3a03e3f23c'] = 'Brak wpisów';
