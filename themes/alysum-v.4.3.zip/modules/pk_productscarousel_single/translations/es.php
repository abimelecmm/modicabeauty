<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_productscarousel_single}alysum>pk_productscarousel_single_2d0f6b8300be19cf35e89e66f0677f95'] = 'Comprar';
$_MODULE['<{pk_productscarousel_single}alysum>pk_productscarousel_single_4351cfebe4b61d8aa5efa1d020710005'] = 'Vista';
