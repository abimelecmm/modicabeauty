<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bc3e73cfa718a3237fb1d7e1da491395'] = 'Herstellerblock';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_9859921e6d3733788e09599adb681dcd'] = 'Zeigt einen Hersteller-/ Markenblock an';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'Ungültige Anzahl von Elementen';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bb30aac3161f999a357af767ce2fd7ec'] = 'Bitte aktivieren Sie mindestens eine Systemliste';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bfdff752293014f11f17122c92909ad5'] = 'Verwenden Sie eine Nur-Text-Liste';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Anzeige';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_6a7f245843454cf4f28ad7c5e2572aa2'] = 'Elemente';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_2e5acd674f7f821a81e99ed01d5305d1'] = 'So zeigen Hersteller in einer Nur-Text-Liste';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_b0fa976774d2acf72f9c62e9ab73de38'] = 'Verwenden Sie eine Dropdown-Liste';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_f68d82d608d94a571e0984a0288595e0'] = 'So zeigen Sie Hersteller in einem Dropdown-Liste';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Hersteller';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_49fa2426b7903b3d4c89e2c1874d9346'] = 'Mehr darüber';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bf24faeb13210b5a703f3ccef792b000'] = 'Alle Hersteller';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_1c407c118b89fa6feaae6b0af5fc0970'] = 'Kein Hersteller';
