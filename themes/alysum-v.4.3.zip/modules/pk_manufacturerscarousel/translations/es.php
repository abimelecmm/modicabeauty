<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bc3e73cfa718a3237fb1d7e1da491395'] = 'Bloque de marcas';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_9859921e6d3733788e09599adb681dcd'] = 'Mostrar bloque de marcas';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'número de elementos no válido';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bb30aac3161f999a357af767ce2fd7ec'] = 'Por favor, active al menos uno de la lista';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_c888438d14855d7d96a2724ee9c306bd'] = 'Actualización realizada con éxito';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bfdff752293014f11f17122c92909ad5'] = 'Usar una lista de texto plano';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Mostrar';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_6a7f245843454cf4f28ad7c5e2572aa2'] = 'elementos';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_2e5acd674f7f821a81e99ed01d5305d1'] = 'Para mostrar marcas en une lista de texto plano';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_b0fa976774d2acf72f9c62e9ab73de38'] = 'Usar un cuadro combinado';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_f68d82d608d94a571e0984a0288595e0'] = 'Para mostrar las marcas dentro de un cuadro combinado';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Marcas';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_49fa2426b7903b3d4c89e2c1874d9346'] = 'Más sobre';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_bf24faeb13210b5a703f3ccef792b000'] = 'Todas las marcas';
$_MODULE['<{pk_manufacturerscarousel}alysum>pk_manufacturerscarousel_1c407c118b89fa6feaae6b0af5fc0970'] = 'Sin marcas';
