<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_f7dc297e2a139ab4f5a771825b46df43'] = 'Abmeldung erfolgreich';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_8dc3b88902df97bb96930282e56ed381'] = 'E-Mail-Adresse ist bereits registriert';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_b7d9eb38dd2e375648ab08e224e22e43'] = 'Fehler bei der Anmeldung';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_b2485e09e6a72c45d35286d3fc63e128'] = 'Eine Überprüfung per E-Mail wurde abgeschickt. Bitte überprüfen Sie Ihre E-Mail.';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_ed3cd7b3cc134222fa70602921ec27e1'] = 'Abonnement erfolgreich';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_9e1f0c4c3f90d775eafbb0854ec63808'] = 'E-Mail bereits registrierten oder ungültigen';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_4e1c51e233f1ed368c58db9ef09010ba'] = 'Danke für die Anmeldung zu unserem Newsletter an.';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_56e19a5dd98abccaf66ef9c6aa9c8db8'] = 'Triff dich mit uns!';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_434e318d4b5cd678a4e3efe5705d41a1'] = 'Abonnieren Sie die neuesten Nachrichten von Ihren bevorzugten Marken.';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_9b7f4d9dbcd12c240ca94d6254d461ec'] = 'Werden Sie VIP';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_3662c9af1b174a423f6a615c8a75b446'] = 'Registrieren Sie exklusive Angebote aus Ihrem Lieblings-Marken zu erhalten!';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_416f61a2ce16586f8289d41117a2554e'] = 'Ihre E-Mail';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_b26917587d98330d93f87808fc9d7267'] = 'Zeichnen';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_4182c8f19d40c7ca236a5f4f83faeb6b'] = 'Abmelden';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_94966d90747b97d1f0f206c98a8b1ac3'] = 'Senden';
