<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_f7dc297e2a139ab4f5a771825b46df43'] = 'retirada de un éxito ';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_8dc3b88902df97bb96930282e56ed381'] = 'Dirección de correo electrónico ya está registrado';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_b7d9eb38dd2e375648ab08e224e22e43'] = 'Error durante la suscripción de';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_b2485e09e6a72c45d35286d3fc63e128'] = 'Un correo electrónico de verificación ha sido enviada. Por favor, consultar su correo electrónico.';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_ed3cd7b3cc134222fa70602921ec27e1'] = 'Suscripción exitosa';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_9e1f0c4c3f90d775eafbb0854ec63808'] = 'E-mail ya está registrado o no válido';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_4e1c51e233f1ed368c58db9ef09010ba'] = 'Gracias por suscribirse a nuestro boletín.';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_56e19a5dd98abccaf66ef9c6aa9c8db8'] = 'Somos sociales';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_434e318d4b5cd678a4e3efe5705d41a1'] = 'Suscríbete a las últimas noticias de tus marcas favoritas.';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_9b7f4d9dbcd12c240ca94d6254d461ec'] = 'Usted está VIP';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_3662c9af1b174a423f6a615c8a75b446'] = 'Inscríbase para recibir ofertas exclusivas de sus marcas favoritas!';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_416f61a2ce16586f8289d41117a2554e'] = 'su dirección de e-mail';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_b26917587d98330d93f87808fc9d7267'] = 'suscribir';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_4182c8f19d40c7ca236a5f4f83faeb6b'] = 'Darse de baja ';
$_MODULE['<{blocknewsletter_ext}prestashop>blocknewsletter_ext_94966d90747b97d1f0f206c98a8b1ac3'] = 'Enviar';
