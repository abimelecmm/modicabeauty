<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{editorial}prestashop>editorial_a46dcd3561c3feeb53903dfc0f796a35'] = 'Home text editor';
$_MODULE['<{editorial}prestashop>editorial_48b5a6f8c5a4e81cd8eb07678a981649'] = 'A text-edit module for your homepage.';
$_MODULE['<{editorial}prestashop>editorial_5db205c79efd29b0e4f52d0c1ff45d20'] = 'Save ';
$_MODULE['<{editorial}prestashop>editorial_0245625ee10f9c6c0ed7f50eb1838856'] = 'Main title';
$_MODULE['<{editorial}prestashop>editorial_4fb7f07fcf38a6401743822ade34e782'] = 'Appears along top of your homepage';
$_MODULE['<{editorial}prestashop>editorial_e1f46be647e598f00eeb0ab62561d695'] = 'Subheading';
$_MODULE['<{editorial}prestashop>editorial_bf75f228011d1443c4ea7aca23c3cff2'] = 'Introductory text';
$_MODULE['<{editorial}prestashop>editorial_617f7661941abbf06f773fcb10031c7a'] = 'For example... explain your mission, highlight a new product, or describe a recent event.';
$_MODULE['<{editorial}prestashop>editorial_78587f196180054fcb797d40f4a86f10'] = 'Homepage logo';
$_MODULE['<{editorial}prestashop>editorial_28d74ee805e3a162047d8f917b74dcb3'] = 'Homepage logo link';
$_MODULE['<{editorial}prestashop>editorial_98039e8f2a0d93fc0fff503f9166f59b'] = 'Homepage logo subheading';
$_MODULE['<{editorial}prestashop>editorial_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{editorial}prestashop>editorial_2563cfff94f1447b53116f3089940125'] = 'This action cannot be made.';
$_MODULE['<{editorial}prestashop>editorial_5526efd7014a00a73115bcf90883d968'] = 'An error occurred while attempting to upload the image.';
$_MODULE['<{editorial}prestashop>editorial_8dd2f915acf4ec98006d11c9a4b0945b'] = 'Settings updated successfully.';


return $_MODULE;
