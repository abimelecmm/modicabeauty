<?php

global $_MODULE;
$_MODULE = array();


return $_MODULE;
