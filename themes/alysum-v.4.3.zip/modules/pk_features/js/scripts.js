$(document).ready(function(){
  	parallax($("#pk_features"));
});