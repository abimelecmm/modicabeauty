<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_dd8c84ae3dc95566dc071d0effc40dd2'] = 'Nos produits';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_daa9fcd9a94e47e96c35c8c2551378be'] = 'Sauvez du temps et de l\'argent sur notre site.  Voici une sélection impressionnante de nos produits';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Tout';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_15422d54ec0d47000dc86a9820a5237e'] = 'En vedette';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_b4c2b550635fe54fd29f2b64dfaca55d'] = 'En rabais';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_cd118d21c3b0b4762c6e0063661e6e45'] = 'Dernier';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_babba85d52b4221d3f44a6912d1b8e4f'] = 'Les + vendus';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
$_MODULE['<{pk_isotopesort}alysum>pk_isotopesort_3ec365dd533ddb7ef3d1c111186ce872'] = 'Détails';
